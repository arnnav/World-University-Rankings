var year = "2016";
var final_data = [];
var current_data = [];
var country_data = {};
d3.selection.prototype.moveToFront = function() {
    return this.each(function(){
        this.parentNode.appendChild(this);
    });
};
d3_queue.queue()
      .defer(d3.json,'http://127.0.0.1:9000/data')
      .await(function (error, data_json) {
        final_data = data_json.filter(function (d) {
                return d.year === year;
            }).map(function (d) {
                if (d.world_rank[0] === "=") {
                    d.world_rank = d.world_rank.substr(1);
                }
                d.world_rank = parseInt(d.world_rank);
                return d;
            });
        current_data = JSON.parse(JSON.stringify(final_data));
        world_map();
        get_pc();
        get_histogram(data_json,'international')
      });


var map_chart_div = d3.select("#map_chart_div");

var map_width  = +map_chart_div.attr("width"),
    map_height = +map_chart_div.attr("height"),
    map_active = d3.select(null);

var map_legend_rect_size = 10;
var map_legend_spacing = 2;

var map_projection = d3.geo.mercator()
    .scale(map_width/6)
    .translate([map_width / 2, map_height / 2]);

var map_path = d3.geo.path()
    .projection(map_projection);

var map_svg = map_chart_div.append("svg")
    .attr("id", "map_chart_svg")
    .attr("width", map_width)
    .attr("height", map_height);

map_svg.append("rect")
    .attr("class", "map_background")
    .attr("fill", "white")
    .attr("width", map_width)
    .attr("height", map_height)
    .on("click", map_reset);

var map_g = map_svg.append("g")
    .style("stroke-width", ".5px");

var map_colors = ["#67000d", "#a50f15", "#cb181d", "#fb6a4a", "#fee0d2", "#ccc"];

var map_tooltip = d3.select("body").append("div")
                    .attr("class", "maptooltip")
                    .attr("width", map_width/10)
                    .attr("height", map_height/10)
                    .style("opacity", 0);

var map_selected = "World";

function world_map() {
    country_id_to_name_map = {};
    d3_queue.queue()
          .defer(d3.json, "http://127.0.0.1:9000/world_country")
          .await(function (error, mapping_json) {
            for (var i = 0; i < mapping_json.length; i++) {
              country_id_to_name_map[mapping_json[i]["country-code"]] = mapping_json[i]["name"];
            }

            d3.json("http://127.0.0.1:9000/world", function(error, world) {
              if (error) throw error;

              var color_domain = [9,6,5,3,0,-1];
              var color_exps = [">100", "50 - 100", "25 - 50", "10 - 25", "<10", "Zero/No data"]

              map_g.selectAll("path")
                  .data(topojson.feature(world, world.objects.countries).features)
                .enter().append("path")
                  .attr("country_name", function(d) {return country_id_to_name_map[d.id];})
                  .attr("d", map_path)
                  .attr("class", "mapfeature")
                  .style("fill", "#ccc")
                  .on("click", map_clicked)
                  .on("mouseover", map_mouseover)
                  .on("mouseout", map_mouseout);

              map_g.append("path")
                  .datum(topojson.mesh(world, world.objects.countries, function(a, b) { return a !== b; }))
                  .attr("class", "mesh")
                  .attr("d", map_path);

              color_map();
            });
        });  
}

function map_clicked(d) {
  var country_name = d3.select(this).attr("country_name");

  if (!(country_name in country_data)) {
    return;
  }
  if (map_active.node() === this) return map_reset();
  map_active.classed("active", false);
  map_active = d3.select(this).classed("active", true);

  current_data = current_data.filter(function(d) {
    return (d.country === country_name);
  });

  var bounds = map_path.bounds(d),
      dx = bounds[1][0] - bounds[0][0],
      dy = bounds[1][1] - bounds[0][1],
      x = (bounds[0][0] + bounds[1][0]) / 2,
      y = (bounds[0][1] + bounds[1][1]) / 2,
      scale = .9 / Math.max(dx / map_width, dy / map_height),
      translate = [map_width / 2 - scale * x, map_height / 2 - scale * y];

  map_g.transition()
      .duration(750)
      .style("stroke-width", .5 / scale + "px")
      .attr("transform", "translate(" + translate + ")scale(" + scale + ")");
  d3.select(this).moveToFront();
  d3.select(this).transition()
                 .duration(750)
                 .style("stroke", "yellow")
                 .style("stroke-width", (2.5 / scale) + "px");

  map_selected = country_name;
  update_pc();
}

function map_reset() {
  map_active.classed("active", false);
  map_active = d3.select(null);

  console.log(current_data.length);
  current_data=final_data

  map_g.transition()
      .duration(750)
      .style("stroke-width", ".5px")
      .attr("transform", "");
  
  d3.selectAll(".mapfeature").transition()
                 .duration(750)
                 .style("stroke", "white")
                 .style("stroke-width", ".5px");

  map_selected = "World";
  update_pc()
}

function map_mouseover() {
  this_el = d3.select(this);
  var country_name = this_el.attr("country_name");
  map_tooltip.transition().duration(100).style("opacity", 1);
  map_tooltip.html(country_name + ": " + (country_data[country_name] || 0))
         .style("left", (d3.event.pageX + 5) + "px")
         .style("top", (d3.event.pageY - 15) + "px")
         .style("font-size",17+"px");
}

function map_mouseout() {
  map_tooltip.transition().duration(100).style("opacity", 0);
}

function color_map() {
    country_data = {};
    current_data.map(function (d) {
        country_data[d.country] = (country_data[d.country] || 0) + 1;
    });
    map_g.selectAll(".mapfeature")
         .transition()
         .duration(500)
         .style("fill", function(d, i) {
            return get_color(d3.select(this));
        });
    function get_color(d) {
        var country_name = d.attr("country_name");
        var country_color = map_colors[5]; 
        if (!(country_name in country_data)) {
            country_color = map_colors[5]; ;
        } else {
            var cnt = country_data[country_name];
            if (cnt >= 100) {
                country_color = map_colors[0];
            } else if (cnt < 100 && cnt >= 50) {
                country_color = map_colors[1];
            } else if (cnt < 50 && cnt >= 25) {
                country_color = map_colors[2];
            } else if (cnt < 25 && cnt >= 10) {
                country_color = map_colors[3];
            } else {
                country_color = map_colors[4];
            }
        }
        return country_color;
    }
    
}


function update_pc() {
  console.log("here");
  pc_svg.remove();
  pc_svg = pc_parent_svg.append("g")
                          .attr("transform", "translate(" + pc_margin.left + "," + pc_margin.top + ")");
  get_pc();
}

function get_histogram(csvdata, field){
    var num_bins = 15;
    data = [];
    for (i=0; i<csvdata.length; i++)
    {
        data.push(parseFloat(csvdata[i][field]))
    }
    binning_the_data(data, field, num_bins)
}

function binning_the_data(data,field,num_bins) {
    document.getElementById("histogram").innerHTML = "";
    var color = d3.scale.category20();
    var min_data = d3.min(data);
    var max_data = d3.max(data);
    var bin_size = (max_data - min_data)/ num_bins ;
    var binmargin = (max_data - min_data)*0.008;

    var margin = {top: 10, right: 30, bottom: 50, left: 60};
        var width = 650 - (margin.left+100) - margin.right;
        var height = 400 - (margin.top+40) - margin.bottom;

        var xmin = min_data ;
        var xmax = max_data ;

    histogram_data = new Array(num_bins);
    for(var i=0; i<num_bins; i++)
    {
        histogram_data[i] = {numfill: 0, range: (min_data + i*bin_size).toFixed(2) + " - " + (min_data + (i+1)*bin_size).toFixed(2)};
    }

       data.forEach(function(d) {
        var bin = Math.floor((d - min_data) / bin_size);
        if ((bin.toString() != "NaN") && (bin < histogram_data.length)) {
            histogram_data[bin].numfill += 1;
        }
       });

       var x = d3.scale.linear()
         .domain([0, (xmax - xmin)])
         .range([0, width]);

       var x2 = d3.scale.linear()
              .domain([xmin, xmax])
          .range([0, width]);

       var y = d3.scale.linear()
             .domain([0, d3.max(histogram_data, function(d) {
                        return d.numfill;
                        })])
         .range([height, 0]);

       var xAxis = d3.svg.axis()
                 .scale(x2)
             .ticks(num_bins)
             .orient("bottom");


       var yAxis = d3.svg.axis()
             .scale(y)
             .ticks(8)
             .orient("left");

    var tip = d3.tip()
        .attr('class', 'd3-tip')
        .offset([-10, 0])
        .html(function(d) {
            return "<strong>Number of universities :</strong> <span style='color:red'>" + d.numfill + "</span>";
            })

    var svg = d3.select("#histogram").append("svg")
            .attr("width", width + (margin.left+30) + margin.right)
            .attr("height", height + (margin.top+40) + margin.bottom)
            .append("g")
            .attr("transform", "translate(" + (margin.left+10) + "," +
                        (margin.top+40) + ")");

    svg.call(tip);

        var bar = svg.selectAll(".bar")
            .data(histogram_data)
            .enter().append("g")
            .attr("class", "bar")
            .attr("transform", function(d, i) { return "translate(" +
             x2(i * bin_size + min_data) + "," + y(d.numfill) + ")"; })
            .style("fill", function(d,i) {
                    return color(i); })

    bar.append("rect")
        .attr("x", x(binmargin))
        .attr("width", x(bin_size - 2 * binmargin))
        .attr("height", function(d) { return height - y(d.numfill); })
        .on({
            "mouseover": function(d,i){

                d3.select(this)
                    .attr("y",d3.select(this).attr("y") - 15)
                    .attr("height",parseInt(d3.select(this).attr("height")) + 15)
                    .attr("x",x(binmargin) - 5)
                    .attr("width",x(bin_size -2 *binmargin) + 10)
                tip.show(d);
            } ,
            "mouseout": function(d,i){
                tip.hide(d);
                d3.select(this)
                    .attr("y",parseInt(d3.select(this).attr("y")) + 15)
                    .attr("height",parseInt(d3.select(this).attr("height")) - 15)
                    .attr("x",x(binmargin))
                    .attr("width",x(bin_size -2 *binmargin))

            } ,
                "click":  function(d,i) {
            tip.hide(d);
            get_pie_chart(data,histogram_data,field);
          },
            })

        svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis)
            

    if(field == 'teaching')
        x_text = 'Teaching'
    else if(field == 'international')
        x_text = 'International'
    else if(field == 'research')
        x_text = 'Research'
    else if(field == 'citations')
        x_text = 'Citations'
    else if(field == 'income')
      x_text = 'Income'
    else
        x_text = ''

    svg.append("text")
        .attr("class", "xlabel")
        .attr("text-anchor", "middle")
        .attr("x", width / 2)
        .attr("y", height + margin.bottom - 10)
        .text(x_text);

    svg.append("g")
        .attr("class", "y axis")
        .attr("transform", "translate(0,0)")
        .call(yAxis);

    svg.append("text")
        .attr("class", "ylabel")
        .attr("y", 0 - (margin.left)) 
        .attr("x", 0 - (height / 2))
        .attr("dy", "1em")
        .attr("transform", "rotate(-90)")
        .style("text-anchor", "middle")
        .text("Number of Universities");
}

function data_helper() {
    var new_data = current_data.map(function (d) {
      cols = ["world_rank", "teaching", "research", "citations", "international", "total_score"];
      arr = []
      new_d = {}
      for (var i = 0; i < cols.length; i++) {
            new_d[cols[i]] = parseFloat(d[cols[i]]);
      }
      return new_d;
    });
    return new_data;
  }
  
  var pc_div = d3.select("#pc_div");
  
  var pc_margin = {top: 30, right: 10, bottom: 10, left: 10},
      width = 1200 - pc_margin.left - pc_margin.right,
      height = 350 - pc_margin.top - pc_margin.bottom;
  
  var x = d3.scale.ordinal().rangePoints([0, width], 1),
      y = {},
      dragging = {};
  
  var pc_line = d3.svg.line(),
      axis = d3.svg.axis().orient("left"),
      background,
      foreground;
  
  var pc_parent_svg = pc_div.append("svg")
      .attr("id", "pc_svg")
      .attr("width", width + pc_margin.left + pc_margin.right)
      .attr("height", height + pc_margin.top + pc_margin.bottom);
  
  var pc_svg = pc_parent_svg.append("g")
                            .attr("transform", "translate(" + pc_margin.left + "," + pc_margin.top + ")");
  
  function get_pc() {
  
      pc_times_data = data_helper();
  
      x.domain(dimensions = d3.keys(pc_times_data[0]).filter(function(d) {
        if (d === "world_rank") {
          return y[d] = d3.scale.linear()
             .domain(d3.extent(pc_times_data, function(p) { return +p[d]; }))
             .range([0, height]);
        }
        return y[d] = d3.scale.linear()
            .domain(d3.extent(pc_times_data, function(p) { return +p[d]; }))
            .range([height, 0]);
      }));
  
      background = pc_svg.append("g")
          .attr("class", "background")
        .selectAll("path")
          .data(pc_times_data)
        .enter().append("path")
          .attr("d", path);
  
      foreground = pc_svg.append("g")
          .attr("class", "foreground")
        .selectAll("path")
          .data(pc_times_data)
        .enter().append("path")
          .attr("d", path);
  
      var g = pc_svg.selectAll(".dimension")
          .data(dimensions)
        .enter().append("g")
          .attr("class", "dimension")
          .attr("transform", function(d) { return "translate(" + x(d) + ")"; })
          .call(d3.behavior.drag()
            .origin(function(d) { return {x: x(d)}; })
            .on("dragstart", function(d) {
              dragging[d] = x(d);
              background.attr("visibility", "hidden");
            })
            .on("drag", function(d) {
              dragging[d] = Math.min(width, Math.max(0, d3.event.x));
              foreground.attr("d", path);
              dimensions.sort(function(a, b) { return position(a) - position(b); });
              x.domain(dimensions);
              g.attr("transform", function(d) { return "translate(" + position(d) + ")"; })
            })
            .on("dragend", function(d) {
              delete dragging[d];
              transition(d3.select(this)).attr("transform", "translate(" + x(d) + ")");
              transition(foreground).attr("d", path);
              background
                  .attr("d", path)
                .transition()
                  .delay(500)
                  .duration(0)
                  .attr("visibility", null);
            }));
  
      g.append("g")
          .attr("class", "axis")
          .each(function(d) { d3.select(this).call(axis.scale(y[d])); })
          .append("text")
          .style("text-anchor", "middle")
          .attr("y", -9)
          .text(function(d) { return d; });
  
      g.append("g")
          .attr("class", "brush")
          .each(function(d) {
            d3.select(this).call(y[d].brush = d3.svg.brush().y(y[d]).on("brushstart", brushstart).on("brush", brush));
          })
          .selectAll("rect")
          .attr("x", -8)
          .attr("width", 16);
  
  
    function position(d) {
      var v = dragging[d];
      return v == null ? x(d) : v;
    }
  
    function transition(g) {
      return g.transition().duration(500);
    }
  
    function path(d) {
      return pc_line(dimensions.map(function(p) { return [position(p), y[p](d[p])]; }));
    }
  
    function brushstart() {
      d3.event.sourceEvent.stopPropagation();
    }
  
    function brush() {
      var actives = dimensions.filter(function(p) { return !y[p].brush.empty(); }),
          extents = actives.map(function(p) { return y[p].brush.extent(); });
      foreground.style("display", function(d) {
        return actives.every(function(p, i) {
          return extents[i][0] <= d[p] && d[p] <= extents[i][1];
        }) ? null : "none";
      });
    }
  }
  