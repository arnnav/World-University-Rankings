// var margin = { top: 20, right: 180, bottom: 80, left: 180 },
// 	width = 1200 - margin.left - margin.right,
// 	height = 600 - margin.top - margin.bottom;

const format = d3.format(",d");
var width = 580;
var height = 300;
const radius = width / 6;
var depth=0;

var drop_down_list = ['Stanford University',
	'Harvard University',
	'California Institute of Technology',
	'Massachusetts Institute of Technology',
	'Princeton University',
	'University of Cambridge',
	'University of Oxford',
	'University of California, Berkeley',
	'Imperial College London',
	'Yale University',
	'Stony Brook University',
	'University of California, Los Angeles',
	'University of Chicago',
	'Johns Hopkins University',
	'Cornell University',
	'University of Toronto',
	'Columbia University',
	'University of Pennsylvania',
	'Carnegie Mellon University',
	'University College London',
	'University of Washington',
	'Duke University',
	'Northwestern University',
	'Georgia Institute of Technology',
	'Pohang University of Science and Technology',
	'University of California, Santa Barbara',
	'University of North Carolina at Chapel Hill',
	'University of British Columbia',
	'University of California, San Diego',
	'National University of Singapore',
	'McGill University',
	'University of Melbourne',
	'Peking University',
	'Karolinska Institute',
	'Rice University',
	'University of California, Irvine',
	'University of Science and Technology of China',
	'Vanderbilt University',
	'Tufts University',
	'University of California, Davis',
	'Brown University',
	'Kyoto University',
	'Tsinghua University',
	'Boston University',
	'New York University',
	'Emory University',
	'University of Notre Dame',
	'University of Pittsburgh',
	'Case Western Reserve University',
	'Yeshiva University',
	'University of California, Santa Cruz',
	'University of Bristol',
	'University of Sydney',
	'University of Virginia',
	'University of Southern California',
	'University of Sussex',
	'University of York',
	'University of Rochester',
	'University of Utah',
	'Heidelberg University',
	'Durham University',
	'Royal Holloway, University of London',
	'Lund University',
	'University of Zurich',
	'Wake Forest University',
	'University of Southampton',
	'McMaster University',
	'University College Dublin',
	'University of Arizona',
	'University of Basel',
	'University of Maryland, College Park',
	'Dartmouth College',
	'University of Helsinki',
	'University of St Andrews',
	'Rensselaer Polytechnic Institute',
	'University of Cape Town',
	'National Tsing Hua University',
	'Seoul National University',
	'Hong Kong Baptist University',
	'Bilkent University',
	'Tokyo Institute of Technology',
	'University of Bern',
	'Eindhoven University of Technology',
	'National Taiwan University',
	'University of California, Riverside',
	'University of Geneva',
	'KU Leuven',
	'Queen Mary University of London',
	'Nanjing University',
	'Michigan State University',
	'Technical University of Denmark',
	'Leiden University',
	'Ghent University',
	'Lancaster University',
	'University of Florida',
	'University of Alberta',
	'Stockholm University',
	'Osaka University',
	'University of Victoria',
	'University of Freiburg',
	'Tohoku University',
	'University of Iowa',
	'University of Bergen',
	'University of Lausanne',
	'University of Montreal',
	'VU University Amsterdam',
	'University of Barcelona',
	'Utrecht University',
	'University of Birmingham',
	'Uppsala University',
	'Alexandria University',
	'University of Aberdeen',
	'Brandeis University',
	'Delft University of Technology',
	'University of New South Wales',
	'Birkbeck, University of London',
	'Newcastle University',
	'Pompeu Fabra University',
	'Iowa State University',
	'University of Warwick',
	'Radboud University Nijmegen',
	'University of Delaware',
	'Erasmus University Rotterdam',
	'Arizona State University',
	'Boston College',
	'Medical University of South Carolina',
	'Texas A&M University',
	'Georgetown University',
	'University of Amsterdam',
	'University of Liverpool',
	'Tel Aviv University',
	'Aarhus University',
	'University of Leeds',
	'University of Groningen',
	'Sun Yat-sen University',
	'University of Miami',
	'Bielefeld University',
	'University of Nottingham',
	'Nanyang Technological University',
	'University of East Anglia',
	'Syracuse University',
	'University of Copenhagen',
	'University of Bonn',
	'Monash University',
	'National Chiao Tung University',
	'University of Oslo',
	'RWTH Aachen University',
	'Middle East Technical University',
	'University of Exeter',
	'University of Ottawa',
	'University of Twente',
	'University of Konstanz',
	'University of Innsbruck',
	'Yonsei University',
	'University of Cincinnati',
	'Drexel University',
	'City University of Hong Kong',
	'Dalhousie University',
	'University of Vienna',
	'Kent State University',
	'Maastricht University',
	'University of Illinois at Chicago',
	'University of Leicester',
	'Zhejiang University',
	'Simon Fraser University',
	'Swedish University of Agricultural Sciences',
	'Rush University',
	'University of Waterloo',
	'Northeastern University',
	'University of Otago',
	'Cardiff University',
	'Nagoya University',
	'University of Gothenburg',
	'Colorado School of Mines',
	'Autonomous University of Barcelona',
	'University of Erlangen-Nuremberg',
	'Tulane University',
	'University of Strasbourg',
	'Florida State University',
	'University of Essex',
	'Carleton University',
	'University of Padua',
	'Colorado State University',
	'Panjab University',
	'University of Hamburg',
	'Laval University',
	'Florida Institute of Technology',
	'Macquarie University',
	'University of Bologna',
	'Indian Institute of Technology Kharagpur',
	'Fudan University',
	'Chalmers University of Technology',
	'Tokyo Metropolitan University',
	'Technical University of Berlin',
	'Korea University',
	'University of Trieste',
	'University of Milan',
	'James Cook University',
	'University of Graz',
	'Federico Santa María Technical University',
	'University of Bremen',
	'University of the Witwatersrand',
	'TU Dresden',
	'Kyushu University',
	'University of Southern Denmark',
	'Saint Louis University',
	'Norwegian University of Science and Technology',
	'Aix-Marseille University',
	'Stellenbosch University',
	'University of Wollongong',
	'University of Bordeaux',
	'Victoria University of Wellington',
	'University of Oregon',
	'University of Connecticut',
	'University of Tsukuba',
	'Wayne State University',
	'University of Kiel',
	'University of Cologne',
	'University of Bath',
	'Bangor University',
	'Tilburg University',
	'Virginia Polytechnic Institute and State University',
	'University of Iceland',
	'University of Antwerp',
	'Oregon State University',
	'Istanbul Technical University',
	'University of Macau',
	'Aberystwyth University',
	'University of Newcastle',
	'Autonomous University of Madrid',
	'Queensland University of Technology',
	'University of Crete',
	'University of Kansas',
	'University of Kentucky',
	'University of Trento',
	'University of Guelph',
	'Indian Institute of Science',
	'Hokkaido University',
	'York University',
	'University of Turin',
	'University of Tampere',
	'Vienna University of Technology',
	'Plymouth University',
	'Aalto University',
	'Medical College of Wisconsin',
	'University of Nebraska Medical Center',
	'University of Porto',
	'George Mason University',
	'National Cheng Kung University',
	'Claude Bernard University Lyon 1',
	'Gwangju Institute of Science and Technology',
	'Bar-Ilan University',
	'University of Eastern Finland',
	'University of Greifswald',
	'University of Ferrara',
	'Charles University in Prague',
	'Jagiellonian University',
	'Medical University of Vienna',
	'Keio University',
	'University of Aveiro',
	'Illinois Institute of Technology',
	'University of Houston',
	'University of Hull',
	'Washington State University',
	'Technical University of Dortmund',
	'King Abdulaziz University',
	'Keele University',
	'University of Naples Federico II',
	'University of Modena and Reggio Emilia',
	'Sapienza University of Rome',
	'Murdoch University',
	'University of Pisa',
	'Novosibirsk State University',
	'Aalborg University',
	'University of Portsmouth',
	'University of Hohenheim',
	'University of Pavia',
	'University of Canterbury',
	'University of Manitoba',
	'University of Fribourg',
	'University of Surrey',
	'Indian Institute of Technology Bombay',
	'University of Maryland, Baltimore County',
	'University of Hertfordshire',
	'University of Valencia',
	'Renmin University of China',
	'Lehigh University',
	'University of Stirling',
	'Sharif University of Technology',
	'University of Stuttgart',
	'University of South Florida',
	'University of Tasmania',
	'University of Vermont',
	'University of Warsaw',
	'Shanghai Jiao Tong University',
	'University College Cork',
	'Wuhan University of Technology',
	'Swinburne University of Technology',
	'Michigan Technological University',
	'Tokyo University of Agriculture and Technology',
	'Saint Petersburg State University',
	'Old Dominion University',
	'New University of Lisbon',
	'University of Salento',
	'Loughborough University',
	'La Trobe University',
	'Griffith University',
	'University of Coimbra',
	'Clemson University',
	'Kobe University',
	'Flinders University',
	'Georgia State University',
	'Liverpool John Moores University',
	'University of South Australia',
	'Wuhan University',
	'Kansas State University',
	'Heriot-Watt University',
	'Harbin Institute of Technology',
	'National Central University',
	'Polytechnic University of Catalonia',
	'Deakin University',
	'New Jersey Institute of Technology',
	'University of Idaho',
	'Massey University',
	'University of Turku',
	'University of Zaragoza',
	'Hiroshima University',
	'University of Tartu',
	'University of Kent',
	'University of Wyoming',
	'Swansea University',
	'National University of Ireland, Galway',
	'Kyung Hee University',
	'Polytechnic University of Turin',
	'Curtin University',
	'Aston University',
	'Polytechnic University of Valencia',
	'Mahidol University',
	'Waseda University',
	'University of Strathclyde',
	'Auburn University',
	'Hanyang University',
	'University of Cyprus',
	'University of KwaZulu-Natal',
	'University of Lisbon',
	'Temple University',
	'Southern Methodist University',
	'Isfahan University of Technology',
	'King Saud University',
	'University of Navarra',
	'National Autonomous University of Mexico',
	'Indian Institute of Technology Roorkee',
	'Ewha Womans University',
	'University of Oulu',
	'University of Florence',
	'Indian Institute of Technology Kanpur',
	'San Diego State University',
	'University of Minho',
	'University of Technology Sydney',
	'University of Vigo',
	'Indian Institute of Technology Delhi',
	'University of Duisburg-Essen',
	'Graz University of Technology',
	'Complutense University of Madrid',
	'University of Parma',
	'National and Kapodistrian University of Athens',
	'University of Ioannina',
	'RMIT University',
	'University of Saskatchewan',
	'University of Cagliari',
	'University of Ulsan',
	'Catholic University of the Sacred Heart',
	'University of Siena',
	'City University London',
	'Howard University',
	'Makerere University',
	'East China University of Science and Technology',
	'University of Nantes',
	'Xiamen University',
	'Indian Institute of Technology Madras',
	'University of Palermo',
	'Marche Polytechnic University',
	'Florida International University',
	'University of Genoa',
	'University of Nice Sophia Antipolis',
	'Concordia University',
	'Huazhong University of Science and Technology',
	'University of La Laguna',
	'University of Maribor',
	'University of Granada',
	'National Technical University of Athens',
	'University of Seville',
	'Masaryk University',
	'China Agricultural University',
	'University of Limerick',
	'Kanazawa University',
	'Tehran University of Medical Sciences',
	'South China University of Technology',
	'Ben-Gurion University of the Negev',
	'University of Pretoria',
	'New Mexico State University',
	'Manchester Metropolitan University',
	'University of Toledo',
	'National Taiwan Normal University',
	'Missouri University of Science and Technology',
	'University of North Carolina at Greensboro',
	'Jadavpur University',
	'Montana State University',
	'University of Haifa',
	'University of Catania',
	'Czech Technical University in Prague',
	'University of Regina',
	'University of Burgundy',
	'Tianjin University',
	'University of Salamanca',
	'University of Oviedo',
	'Osaka City University',
	'Tongji University',
	'Memorial University of Newfoundland',
	'Federal University of Rio de Janeiro',
	'Pusan National University',
	'University of Chile',
	'Portland State University',
	'Amirkabir University of Technology',
	'Oklahoma State University',
	'American University of Beirut',
	'Chung-Ang University',
	'East China Normal University',
	'Semmelweis University',
	'University of Rennes 1',
	'University of the Basque Country',
	'Shinshu University',
	'Carlos III University of Madrid',
	'Konkuk University',
	'AGH University of Science and Technology',
	'University of Bradford',
	'Federal University of Viçosa',
	'Yokohama National University',
	'Chulalongkorn University',
	'University of Murcia',
	'Federal University of Bahia',
	'Shantou University',
	'Sogang University',
	'Budapest University of Technology and Economics',
	'Osaka Prefecture University',
	'Chongqing University',
	'Jilin University',
	'China University of Geosciences (Wuhan)',
	'Vilnius University',
	'Juntendo University',
	'University of Science and Technology Beijing',
	'Gifu University',
	'Ohio University',
	'Okayama University',
	'Kumamoto University',
	'Taipei Medical University',
	'University of Delhi',
	'Nagasaki University',
	'Chang Gung University',
	'University of Ibadan',
	'Chiba University',
	'Sichuan University',
	'Xidian University',
	'Istanbul University',
	'Sejong University',
	'Tottori University',
	'University of Bucharest',
	'Moscow Institute of Physics and Technology',
	'Dalian University of Technology',
	'University of Szeged',
	'Aristotle University of Thessaloniki',
	'University of Tehran',
	'Federal University of Rio Grande do Sul',
	'Federal University of Minas Gerais',
	'Capital Medical University',
	'Warsaw University of Technology',
	'Chungnam National University',
	'Hacettepe University',
	'Beijing Institute of Technology',
	'University of Ljubljana',
	'Ehime University',
	'Chiang Mai University',
	'Hunan University',
	'National Chung Hsing University',
	'Niigata University',
	'University of Calcutta',
	'Northwestern Polytechnical University',
	'University of Patras',
	'Shahid Beheshti University',
	'Kaohsiung Medical University',
	'Yokohama City University',
	'Yeungnam University',
	'Saitama University',
	'Ajou University',
	'Texas Tech University',
	'University of Brasília',
	'Shanghai University',
	'Federal University of Santa Catarina',
	'Cairo University',
	'University of Belgrade',
	'Chonbuk National University',
	'Chonnam National University',
	'Kyungpook National University',
	'Tokyo University of Science',
	'University of Texas at El Paso',
	'Comenius University in Bratislava',
	'University of Debrecen',
	'Erciyes University',
	'Ocean University of China',
	'University of Alcalá',
	'University of Electronic Science and Technology of China']

var selector = d3.select("#uni")
	.append("select")
	.attr("id", "dropdown")
	.on("change", function (d) {
		selection = document.getElementById("dropdown");
		update_pie(selection.value)
		update_line(selection.value)
		update_pca()

	});

selector.selectAll("option")
	.data(drop_down_list)
	.enter().append("option")
	.attr("value", function (d) {
		return d;
	})
	.text(function (d) {
		return d;
	})



const arc = d3.arc()
	.startAngle(d => d.x0)
	.endAngle(d => d.x1)
	.padAngle(d => Math.min((d.x1 - d.x0) / 2, 0.005))
	.padRadius(radius * 1.5)
	.innerRadius(d => d.y0 * radius)
	.outerRadius(d => Math.max(d.y0 * radius, d.y1 * radius - 1));

const partition = data => {
	const root = d3.hierarchy(data)
		.sum(d => d.size)
		.sort((a, b) => b.value - a.value);
	return d3.partition()
		.size([2 * Math.PI, root.height + 1])
		(root);
}


var pie = d3.select('#partitionSVG')
var pie_svg_parent = pie.style("width", width)
	.style("height", "auto")
	.style("font", "12px sans-serif bold");
var pie_svg = pie_svg_parent.append("g")
	.attr("transform", `translate(${width / 2},${width / 2})`);

var padding = 20;
var size = 230;

var pca = d3.select("#pca")
var svg_pca_parent = pca.append("svg")
	.attr("width", size * 3 + padding)
	.attr("height", size * 3 + padding)

var svg_pca = svg_pca_parent.append("g")
	.attr("transform", "translate(" + padding + "," + padding / 2 + ")");


var margin = 40;
var duration = 250;

var lineOpacity = "0.75";
var lineOpacityHover = "0.85";
var otherLinesOpacityHover = "0.1";
var lineStroke = "2.5px";
var lineStrokeHover = "3.5px";

var circleOpacity = '0.85';
var circleOpacityOnLineHover = "0.25"
var circleRadius = 3;
var circleRadiusHover = 6;


var line = d3.select("#chart")
var svg_line_parent = line.append("svg")
	.attr("width", (width + margin) + "px")
	.attr("height", (height + margin) + "px")
var svg_line = svg_line_parent.append('g')
	.attr("transform", `translate(${margin}, ${margin})`);

top_3_pca()
line_chart(drop_down_list[0])
pie_chart(drop_down_list[0])

function pie_chart(name) {

	let n = 0;
	let best_sse = 0;
	let data = null
	const http = new XMLHttpRequest();
	url = 'http://127.0.0.1:9000/pie_chart/' + name;
	http.open("GET", url);
	http.send();
	http.onreadystatechange = (e) => {
		if (http.readyState == 4 && http.status == 200) {
			res = JSON.parse(http.responseText)
			data = res
			console.log(data)


			console.log(data);
			const root = partition(data);
			const color = d3.scaleOrdinal().range(d3.quantize(d3.interpolateRainbow, data.children.length + 1));

			root.each(d => d.current = d);
			console.log(root)



			const path = pie_svg.append("g")
				.selectAll("path")
				.data(root.descendants().slice(1))
				.join("path")
				.attr("fill", d => {
					while (d.depth > 1)
						d = d.parent;
					return color(d.data.name);
				})
				.attr("fill-opacity", d => arcVisible(d.current) ? (d.children ? 0.6 : 0.4) : 0)
				.attr("d", d => arc(d.current));

			path.filter(d => d.children)
				.style("cursor", "pointer")
				.on("click", clicked);

			path.append("title")
				.text(d => `${d.ancestors().map(d => d.data.name).reverse().join("/")}\n${format(d.value)}`);

			const label = pie_svg.append("g")
				.attr("pointer-events", "none")
				.attr("text-anchor", "middle")
				.style("user-select", "none")
				.selectAll("text")
				.data(root.descendants().slice(1))
				.join("text")
				.attr("dy", "0.35em")
				.style("font-size","11px")
				.attr("fill-opacity", d => +labelVisible(d.current))
				.attr("transform", d => labelTransform(d.current))
				.text(d => d.data.name);

			const parent = pie_svg.append("circle")
				.datum(root)
				.attr("r", radius)
				.attr("fill", "none")
				.attr("pointer-events", "all")
				.on("click", clicked);

			function clicked(p) {
				console.log(p)
				if ((p.data.name == "Times" || p.data.name == "CWUR" || p.data.name == "Shanghai") && depth!=2) {
					update_pca(p.data.name)
				}
				else if (p.data.name == "Pie" && p.depth==0)
					update_pca(null)
				depth=p.depth
				parent.datum(p.parent || root);

				root.each(d => d.target = {
					x0: Math.max(0, Math.min(1, (d.x0 - p.x0) / (p.x1 - p.x0))) * 2 * Math.PI,
					x1: Math.max(0, Math.min(1, (d.x1 - p.x0) / (p.x1 - p.x0))) * 2 * Math.PI,
					y0: Math.max(0, d.y0 - p.depth),
					y1: Math.max(0, d.y1 - p.depth)
				});

				const t = pie_svg.transition().duration(750);

				// Transition the data on all arcs, even the ones that aren’t visible,
				// so that if this transition is interrupted, entering arcs will start
				// the next transition from the desired position.
				path.transition(t)
					.tween("data", d => {
						const i = d3.interpolate(d.current, d.target);
						return t => d.current = i(t);
					})
					.filter(function (d) {
						return +this.getAttribute("fill-opacity") || arcVisible(d.target);
					})
					.attr("fill-opacity", d => arcVisible(d.target) ? (d.children ? 0.6 : 0.4) : 0)
					.attrTween("d", d => () => arc(d.current));

				label.filter(function (d) {
					return +this.getAttribute("fill-opacity") || labelVisible(d.target);
				}).transition(t)
					.attr("fill-opacity", d => +labelVisible(d.target))
					.attrTween("transform", d => () => labelTransform(d.current));
			}

			function arcVisible(d) {
				return d.y1 <= 3 && d.y0 >= 1 && d.x1 > d.x0;
			}

			function labelVisible(d) {
				return d.y1 <= 3 && d.y0 >= 1 && (d.y1 - d.y0) * (d.x1 - d.x0) > 0.03;
			}

			function labelTransform(d) {
				const x = (d.x0 + d.x1) / 2 * 180 / Math.PI;
				const y = (d.y0 + d.y1) / 2 * radius;
				return `rotate(${x - 90}) translate(${y},0) rotate(${x < 180 ? 0 : 180})`;
			}

		}
	}
}

function line_chart(name) {

	let n = 0;
	let best_sse = 0;
	let data = null
	const http = new XMLHttpRequest();
	url = 'http://127.0.0.1:9000/line_chart/' + name;
	http.open("GET", url);
	http.send();
	http.onreadystatechange = (e) => {
		if (http.readyState == 4 && http.status == 200) {
			res = JSON.parse(http.responseText)
			data = res
			console.log(data)


			/* Format Data */
			var parseDate = d3.timeParse("%Y");
			data.forEach(function (d) {
				d.values.forEach(function (d) {
					d.date = parseDate(d.date);
					d.price = +d.rank;
				});
			});

			console.log(data)
			/* Scale */
			y_i=0
			y_max=0
			x_i=0
			x_sc=[]
			for (let index = 0; index < data.length; index++) {
				years=data[index].values
				for (let i = 0; i < years.length; i++) {
					if(years[i].price>y_max){
						y_i=index
						y_max=years[i].price
					}
					x_sc.push({'date':years[i].date})
					
				}
				
			}
			console.log(x_sc)
			var xScale = d3.scaleTime()
				.domain(d3.extent(x_sc, d => d.date))
				.range([0, width - margin]);

				var yScale = d3.scaleLinear()
				.domain([1, d3.max(data[y_i].values, d => d.price)+1])
				.range([1, height - margin]);

			var color = d3.scaleOrdinal(d3.schemeCategory10);

			
			/* Add line into SVG */
			var line = d3.line()
				.x(d => xScale(d.date))
				.y(d => yScale(d.price));

			let lines = svg_line.append('g')
				.attr('class', 'lines');

			lines.selectAll('.line-group')
				.data(data).enter()
				.append('g')
				.attr('class', 'line-group')
				.on("mouseover", function (d, i) {
					svg_line.append("text")
						.attr("class", "title-text")
						.style("fill", color(i))
						.text(d.name)
						.attr("text-anchor", "middle")
						.attr("x", (width - margin) / 2)
						.attr("y", 5);
				})
				.on("mouseout", function (d) {
					svg_line.select(".title-text").remove();
				})
				.append('path')
				.attr('class', 'line')
				.attr('d', d => line(d.values))
				.style('stroke', (d, i) => color(i))
				.style('opacity', lineOpacity)
				.on("mouseover", function (d) {
					d3.selectAll('.line')
						.style('opacity', otherLinesOpacityHover);
					d3.selectAll('.circle')
						.style('opacity', circleOpacityOnLineHover);
					d3.select(this)
						.style('opacity', lineOpacityHover)
						.style("stroke-width", lineStrokeHover)
						.style("cursor", "pointer");
				})
				.on("mouseout", function (d) {
					d3.selectAll(".line")
						.style('opacity', lineOpacity);
					d3.selectAll('.circle')
						.style('opacity', circleOpacity);
					d3.select(this)
						.style("stroke-width", lineStroke)
						.style("cursor", "none");
				});


			/* Add circles in the line */
			lines.selectAll("circle-group")
				.data(data).enter()
				.append("g")
				.style("fill", (d, i) => color(i))
				.selectAll("circle")
				.data(d => d.values).enter()
				.append("g")
				.attr("class", "circle")
				.on("mouseover", function (d) {
					d3.select(this)
						.style("cursor", "pointer")
						.append("text")
						.attr("class", "text")
						.text(`${d.price}`)
						.attr("x", d => xScale(d.date) + 5)
						.attr("y", d => yScale(d.price) - 10);
				})
				.on("mouseout", function (d) {
					d3.select(this)
						.style("cursor", "none")
						.transition()
						.duration(duration)
						.selectAll(".text").remove();
				})
				.append("circle")
				.attr("cx", d => xScale(d.date))
				.attr("cy", d => yScale(d.price))
				.attr("r", circleRadius)
				.style('opacity', circleOpacity)
				.on("mouseover", function (d) {
					d3.select(this)
						.transition()
						.duration(duration)
						.attr("r", circleRadiusHover);
				})
				.on("mouseout", function (d) {
					d3.select(this)
						.transition()
						.duration(duration)
						.attr("r", circleRadius);
				});


			/* Add Axis into SVG */
			var xAxis = d3.axisBottom(xScale).ticks(5);
			var yAxis = d3.axisLeft(yScale).ticks(5);

			svg_line.append("g")
				.attr("class", "x axis")
				.attr("transform", `translate(0, ${height - margin})`)
				.call(xAxis)
				.append('text')
				.attr("x", 270)
				.attr("y", 40)
				.attr("fill", "#000")
				.attr("font-size", "12px")
				.text("Year");

			svg_line.append("g")
				.attr("class", "y axis")
				.call(yAxis)
				.append('text')
				.attr("x", -120)
				.attr("y", -30)
				.attr("transform", "rotate(-90)")
				.attr("fill", "#000")
				.attr("font-size", "12px")
				.text("Rank");

		}
	}
}






function top_3_pca(data_name = null) {
	// document.getElementById("options").style.display = "block"

	let data = null
	const http = new XMLHttpRequest();
	url = 'http://127.0.0.1:9000/top_3_pca/';

	if (data_name == null || data_name == "all") {
		url = url + "no"
	} else if (data_name == 'Times') {
		url = url + "times";
	} else if (data_name == 'CWUR') {
		url = url + "cwur";
	}
	else if (data_name == 'Shanghai') {
		url = url + "shanghai";
	}
	http.open("GET", url);
	http.send();
	http.onreadystatechange = (e) => {
		if (http.readyState == 4 && http.status == 200) {
			res = JSON.parse(http.responseText)
			data = res.scatter_matrix

			var x = d3.scaleLinear()
				.range([padding / 2, size - padding / 2]);

			var y = d3.scaleLinear()
				.range([size - padding / 2, padding / 2]);

			var xAxis = d3.axisBottom()
				.scale(x)
				.ticks(6);

			var yAxis = d3.axisLeft()
				.scale(y)
				.ticks(6);

			// document.getElementById("spinner").style.display = "none"

			// d3.select("svg").remove();
			var domainByTrait = {},
				traits = d3.keys(data[0]).filter(function (d) { return d !== "species"; }),

				n = traits.length;

			traits.forEach(function (trait) {
				domainByTrait[trait] = d3.extent(data, function (d) { return d[trait]; });
			});

			xAxis.tickSize(size * n);
			yAxis.tickSize(-size * n);


			svg_pca.selectAll(".x.axis")
				.data(traits)
				.enter().append("g")
				.attr("class", "x axis_scatter")
				.attr("transform", function (d, i) { return "translate(" + (n - i - 1) * size + ",0)"; })
				.each(function (d) { x.domain(domainByTrait[d]); d3.select(this).call(xAxis); });

			svg_pca.selectAll(".y.axis")
				.data(traits)
				.enter().append("g")
				.attr("class", "y axis_scatter")
				.attr("transform", function (d, i) { return "translate(0," + i * size + ")"; })
				.each(function (d) { y.domain(domainByTrait[d]); d3.select(this).call(yAxis); });

			var cell = svg_pca.selectAll(".cell")
				.data(cross(traits, traits))
				.enter().append("g")
				.attr("class", "cell")
				.attr("transform", function (d) { return "translate(" + (n - d.i - 1) * size + "," + d.j * size + ")"; })
				.each(plot);

			cell.filter(function (d) { return d.i === d.j; }).append("text")
				.attr("x", padding)
				.attr("y", padding)
				.attr("dy", ".71em")
				.text(function (d) { return d.x; });

			function plot(p) {
				var cell = d3.select(this);

				x.domain(domainByTrait[p.x]);
				y.domain(domainByTrait[p.y]);

				cell.append("rect")
					.attr("class", "frame")
					.attr("x", padding / 2)
					.attr("y", padding / 2)
					.attr("width", size - padding)
					.attr("height", size - padding);

				cell.selectAll("circle")
					.data(data)
					.enter().append("circle")
					.attr("cx", function (d) { return x(d[p.x]); })
					.attr("cy", function (d) { return y(d[p.y]); })
					.attr("r", 1.5)
					.attr("class", "circle_pca");

			}

			function cross(a, b) {
				var c = [], n = a.length, m = b.length, i, j;
				for (i = -1; ++i < n;) for (j = -1; ++j < m;) c.push({ x: a[i], i: i, y: b[j], j: j });
				return c;
			}

		}
	}

}


function update_pca(name) {
	svg_pca.remove();
	svg_pca = svg_pca_parent.append("g")
		.attr("transform", "translate(" + padding + "," + padding / 2 + ")");
	top_3_pca(name);
}



function update_pie(name) {
	pie_svg.remove();
	pie_svg = pie_svg_parent.append("g")
		.attr("transform", `translate(${width / 2},${width / 2})`);
	pie_chart(name)
}


function update_line(name) {
	svg_line.remove();
	svg_line = svg_line_parent.append("g")
		.attr("transform", `translate(${margin}, ${margin})`);
	line_chart(name)
}